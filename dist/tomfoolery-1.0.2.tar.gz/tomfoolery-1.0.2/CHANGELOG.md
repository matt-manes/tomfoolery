# Changelog

## v1.0.1 (2023-07-01)

#### Fixes

* fix circular import issue
#### Performance improvements

* catch fomatting exceptions
#### Docs

* update readme
## v1.0.0 (2023-07-01)

#### New Features

* add option to specify output in cli
* existing dataclass files can be updated instead of overwritten
#### Refactorings

* sort class and remove unused functions
* ! remove generate_from_file from TomFoolery class


## v0.1.0 (2023-06-25)

#### New Features

* sort imports after generation

