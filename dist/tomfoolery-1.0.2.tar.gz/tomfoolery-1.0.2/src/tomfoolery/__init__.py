from .engine import TomFoolery, generate_from_file

__version__ = "1.0.2"
